
import { GoogleGenAI } from "@google/genai";

if (!process.env.API_KEY) {
    console.warn("API_KEY environment variable not set. Gemini API will not be available.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

export const generateInterviewQuestions = async (userInput: string): Promise<string> => {
    if (!process.env.API_KEY) {
        // Simulate a response if API key is not available
        await new Promise(resolve => setTimeout(resolve, 1000));
        return `
*   Váš popis naznačuje, že jste nervózní z otázek na stres. Můžete mi popsat konkrétní situaci z minulosti, kdy jste se ocitl pod velkým tlakem, a jak jste ji zvládl?
*   Uvádíte silné vůdčí schopnosti. Jak byste reagoval, kdybyste jako velitel zásahu musel dát pokyn, se kterým by váš podřízený nesouhlasil?
*   Co pro vás znamená "týmová práce" v kontextu policejní služby, kde je často nutné spoléhat se jeden na druhého v život ohrožujících situacích?
        `.trim();
    }

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Jsem uchazeč o práci u Policie ČR a připravuji se na psychologický pohovor. Mám následující vlastnosti/obavy: "${userInput}". Vygeneruj 3-5 realistických otázek, které by mi mohl psycholog položit, s ohledem na mou popsanou situaci a požadavky na práci u policie. Otázky uveď jako odrážky ve formátu markdown. Odpovídej v češtině.`,
            config: {
                 systemInstruction: "Jsi pomocník pro přípravu na pracovní pohovor. Tvým úkolem je generovat relevantní otázky na základě vstupu uživatele. Odpovídej pouze seznamem otázek."
            }
        });
        return response.text;
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Nepodařilo se vygenerovat otázky. Zkuste to prosím znovu.");
    }
};